#!/bin/bash
echo "   -------------------------------- "
echo "  --> Fetching Instance status."
instance_state=$(aws ec2 describe-instance-status --query 'InstanceStatuses[*].InstanceState.Name' --output text)
size=${#instance_state}
echo "  --> Instance Status: $instance_state"
sleep 5
instance_id=$(aws ec2 describe-instance-status --query 'InstanceStatuses[*].InstanceId' --output text)
size=${#instance_id}
echo "  --> Instance ID: $instance_id"
sleep 5
instance_zone=$(aws ec2 describe-instance-status --query 'InstanceStatuses[*].AvailabilityZone' --output text)
size=${#instance_zone}
echo "  --> Availability Zone: $instance_zone"
sleep 5
fetch_instance_health=$(aws ec2 describe-instance-status --query 'InstanceStatuses[*].InstanceStatus.Status' --output text)
echo "  --> Instance health check : $fetch_instance_health"
echo "  -------------------------------------------"